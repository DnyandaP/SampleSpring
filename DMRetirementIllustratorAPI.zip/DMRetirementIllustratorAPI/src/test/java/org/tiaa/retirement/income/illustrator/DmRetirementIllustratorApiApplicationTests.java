package org.tiaa.retirement.income.illustrator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DmRetirementIllustratorApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
